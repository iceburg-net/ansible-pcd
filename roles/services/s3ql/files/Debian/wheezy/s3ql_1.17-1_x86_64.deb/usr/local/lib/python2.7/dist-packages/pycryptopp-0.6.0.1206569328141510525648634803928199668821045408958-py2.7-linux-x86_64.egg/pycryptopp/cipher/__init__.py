import aes
import xsalsa20

quiet_pyflakes=[aes, xsalsa20]
